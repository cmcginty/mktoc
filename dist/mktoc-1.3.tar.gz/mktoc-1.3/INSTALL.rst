1. Any one of the following command will install Mktoc.

   a. Use ``pip`` from the `pip package <http://pypi.python.org/pypi/pip>`_::

         pip install mktoc --upgrade --user

   b. Download the source distribution file and install from the
      command line::

         tar xzf mktoc-*.tar.gz
         cd mktoc-*
         python setup.py install --user

2. View online docs or :file:`README` for usage instructions.
